module github.com/canary/pad

go 1.22
